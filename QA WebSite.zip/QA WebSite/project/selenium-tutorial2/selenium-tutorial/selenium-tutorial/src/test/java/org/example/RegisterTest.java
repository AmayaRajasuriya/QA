package org.example;

import java.time.Duration;

import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Author: Sanoj Indrasinghe
 */
public class RegisterTest {

    private WebDriver driver;
    private WebDriverWait wait;

    @BeforeEach
    public void setUp() {
        driver = new EdgeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.manage().window().maximize();
    }

    @AfterEach
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test
    public void testRegister() {
        // Open the registration page
        driver.get("http://localhost/QA%20WebSite/project/register.php");

        // Find and fill the name field
        WebElement nameField = driver.findElement(By.name("name"));
        nameField.sendKeys("Amaya");

        // Find and fill the email field
        WebElement emailField = driver.findElement(By.name("email"));
        emailField.sendKeys("amaya@gmail.com");

        // Find and fill the password field
        WebElement passwordField = driver.findElement(By.name("password"));
        passwordField.sendKeys("1234");

        // Find and fill the confirm password field
        WebElement confirmPasswordField = driver.findElement(By.name("cpassword"));
        confirmPasswordField.sendKeys("1234");

        // Select user type from the dropdown
        Select userTypeSelect = new Select(driver.findElement(By.name("user_type")));
        userTypeSelect.selectByVisibleText("user"); // or "admin" based on what you want to test

        // Find and click the register button
        WebElement registerButton = driver.findElement(By.name("submit"));
        registerButton.click();

        // Handle potential messages (success or error)
        wait.until(ExpectedConditions.or(
            ExpectedConditions.urlToBe("http://localhost/QA%20WebSite/project/login.php"),
            ExpectedConditions.visibilityOfElementLocated(By.className("message"))
        ));

        // Check if redirected to the login page
        if (driver.getCurrentUrl().equals("http://localhost/QA%20WebSite/project/login.php")) {
            System.out.println("Registration successful, redirected to login page.");
        } else {
            // Check for error message
            WebElement messageElement = driver.findElement(By.className("message"));
            String messageText = messageElement.getText();
            System.out.println("Registration error: " + messageText);
        }

        // Verify that the registration process is completed by checking the URL or error messages
        assertTrue(driver.getCurrentUrl().equals("http://localhost/QA%20WebSite/project/login.php") || 
                   driver.findElements(By.className("message")).size() > 0, 
                   "Registration did not complete as expected.");
    }
}
